import Cocoa

// Variable
var greeting = "Hello, playground"
// Reasigning value to a variable
var firstName = "Ted"
firstName = "Rebecca"
firstName = "Keely"
// constant
let character = "Daphne"

let actor = "Denzel Washington"
// Add "" inside a string with backslash
let quote = "Then he trapped a sign saying \"Believe\" and walked away."
print(quote)
// M<ulti line string
let movie = """
A day in
the life of an
Apple engineer
"""
print(movie)
let actorLenght = actor.count // to know the length of a string
print(actorLenght)
print(actor.uppercased())
print(actor.lowercased())
print(movie.hasPrefix("A day"))
